# QMUL-BUPT-Latex-template
QMUL-BUPT-Latex-template 

## Warning

与学校的word版本还是有一定上的排版差别

（江来出了问题，我可不负泽，红豆泥，私密马赛！

## Envirnment

Has been successfully compiled in [overleaf](https://www.overleaf.com/) with complier ```XeLatex```


 ## how to use
 
Check to the Packages.tex to change the header to your project title

> more info is coming

